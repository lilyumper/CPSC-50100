from Course import Course

courseList = []

courseList.append(Course("English", "Ms Lapan"))
courseList.append(Course("Precalculus", "Mrs. Gideon"))
courseList.append(Course("Music Theory", "Mr. Davis"))
courseList.append(Course("Biotechnology", "Ms. Palmer"))
courseList.append(Course("Principals of Technology I", "Ms. Garcia"))
courseList.append(Course("Latin", "Mrs. Barnett"))
courseList.append(Course("AP Us History", "Ms. Johannessen"))
courseList.append(Course("Business Computer Information Systems", "Mr. James"))

Course.getInfo(courseList)