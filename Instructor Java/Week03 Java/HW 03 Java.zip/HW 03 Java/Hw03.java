/**
 * Hw03
 */
public class Hw03 {
  public void print_10_PrimeNumbers1(int input) {
    var count = 0;
    // if the input less than 3 then print 2 and 9 cases are remaining [increase the
    // count by 1]
    // change the start input to 3;
    if (input < 3) {
      input = 3;
      count++;
      System.out.printf(" i=%2d      N=%4d   \n", count, 2);
    }
    // since all prime number are odds Skip even
    if (input % 2 == 0) {
      input++;
    }
    // Check if we reach 10
    while (count < 10) {
      // consider the input is prime number and start testing from 3
      var isPrime = true;
      var test = 3;
      var max = Math.sqrt(input) + 1;

      while (test < max) {
        if (input % test == 0) {
          isPrime = false;
          break;
        }
        // increase the test by 2
        test += 2;
      }

      if (isPrime) {
        count++;
        System.out.printf(" i=%2d      N=%4d   \n", count, input);
      }
      // increase the input by 2
      input += 2;
    }
  }

  public void print_10_PrimeNumbers2(int input) {
    var count = 0;
    // if the input less than 3 then print 2 and 9 cases are remaining [increase the
    // count by 1]
    // change the start input to 3;
    if (input < 3) {
      input = 3;
      count++;
      System.out.printf(" i=%2d      N=%4d   \n", count, 2);
    }
    // since all prime number are odds Skip even
    if (input % 2 == 0) {
      input++;
    }
    // Check if we reach 10
    while (count < 10) {
      if (isPrime(input)) {
        count++;
        System.out.printf(" i=%2d      N=%4d   \n", count, input);
      }
      input += 2;
    }
  }

  public boolean isPrime(int input) {
    if (input == 2) {
      return true;
    }
    if (input % 2 == 0 || input < 2) {
      return false;
    }
    var test = 3;
    var max = Math.sqrt(input) + 1;
    while (test < max) {
      if (input % test == 0) {
        return false;
      }
      test += 2;
    }
    return true;
  }

}
