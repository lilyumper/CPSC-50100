/**
 * Start
 */
public class Start {
  int name;

  public static void main(String[] args) {
    var hw = new Hw03();
    System.out.println("1-----------------");
    hw.print_10_PrimeNumbers1(10000);
    System.out.println("2-----------------");
    hw.print_10_PrimeNumbers2(10000);
    System.out.println("3 Prime 10--------");
    System.out.println(hw.isPrime(10));
    System.out.println("4 Prime 17--------");
    System.out.println(hw.isPrime(17));
    System.out.println("5 Prime 101-------");
    System.out.println(hw.isPrime(101));
    System.out.println("5 Prime -2-------");
    System.out.println(hw.isPrime(-2));
  }
}

/*
 * 120 -- 1...119 -- 1-120/2 1..sqrt(120) 3,5,...,sqrt(n) 10000 100 50
 *
 * 1*120 2*60 3*40 4*30 5*24 6*20 8*15 10*12
 *
 *
 *
 *
 *
 *
 *
 */
